# Put your dataset here

1. Download the CSV from Kaggle:
   https://www.kaggle.com/datasets/taweilo/wine-quality-dataset-balanced-classification
2. Drop the `.csv` file into this `data/` folder.
3. Either:
   - rename it to `wine_quality_classification.csv`, OR
   - leave its original name — as long as it's the only `.csv` file in this
     folder, `src/data_loader.py` will find it automatically.

The loader auto-detects the target/label column (it looks for `quality`,
`quality_label`, `label`, `class`, or `target`) and treats every other
numeric column as a feature, so it will work with the dataset's exact
column names without any code changes.
